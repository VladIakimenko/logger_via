LOG_FILE: str = 'output/log.txt'

SENDER: str = ''
RECEIVER: str = ''
MAIL_SERVER: str = ''
PORT: int = 0
USERNAME: str = ''
PASSWORD:str = ''
